import React, { useState } from 'react';
import { Shield, Server, Database, Lock, FileText, CheckCircle2, ChevronRight, ArrowRight, Terminal, Settings, HardDrive } from 'lucide-react';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

interface OnboardingStepProps {
  number: string;
  title: string;
  description: string;
  details?: string[];
}

interface OnboardingFormData {
  companyName: string;
  contactName: string;
  email: string;
  phone: string;
  serverType: 'physical' | 'virtual';
  environment: string;
  expectedTransactions: string;
}

function App() {
  const [showOnboardingForm, setShowOnboardingForm] = useState(false);
  const [showDockerGuide, setShowDockerGuide] = useState(false);
  const [formData, setFormData] = useState<OnboardingFormData>({
    companyName: '',
    contactName: '',
    email: '',
    phone: '',
    serverType: 'physical',
    environment: '',
    expectedTransactions: ''
  });

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleStartImplementation = () => {
    setShowOnboardingForm(true);
    scrollToSection('onboarding');
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowOnboardingForm(false);
    setShowDockerGuide(true);
    scrollToSection('docker-guide');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-blue-50 to-indigo-50">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center cursor-pointer" onClick={() => scrollToSection('top')}>
              <Shield className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">FraudX</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <button 
                onClick={() => scrollToSection('features')} 
                className="text-gray-600 hover:text-indigo-600 transition duration-300"
              >
                Features
              </button>
              <button 
                onClick={() => scrollToSection('onboarding')} 
                className="text-gray-600 hover:text-indigo-600 transition duration-300"
              >
                Implementation
              </button>
              <button 
                onClick={() => scrollToSection('security')} 
                className="text-gray-600 hover:text-indigo-600 transition duration-300"
              >
                Security
              </button>
            </div>
            <button 
              onClick={handleStartImplementation}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition duration-300"
            >
              Start Implementation
            </button>
          </div>
        </nav>

        <div className="container mx-auto px-6 py-20">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight">
                Enterprise-Grade Fraud Detection for Banks
              </h1>
              <p className="mt-6 text-lg text-gray-600">
                Deploy FraudX locally with our secure, Docker-based implementation. Get AI-powered fraud detection with complete data sovereignty.
              </p>
              <div className="mt-8">
                <button 
                  onClick={handleStartImplementation}
                  className="bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition duration-300 flex items-center"
                >
                  Start Implementation
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
              </div>
            </div>
            <div className="md:w-1/2 mt-10 md:mt-0">
              <img 
                src="https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
                alt="Bank Security Infrastructure"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Onboarding Section */}
      <section id="onboarding" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-4">
            Secure Implementation Process
          </h2>
          <p className="text-center text-gray-600 mb-16 max-w-2xl mx-auto">
            Our enterprise-grade implementation process ensures a smooth deployment while maintaining the highest security standards and data sovereignty.
          </p>

          {showOnboardingForm ? (
            <div className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-lg">
              <h3 className="text-2xl font-semibold mb-6">Implementation Details</h3>
              <form onSubmit={handleFormSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Company Name
                    </label>
                    <input
                      type="text"
                      name="companyName"
                      required
                      value={formData.companyName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Contact Name
                    </label>
                    <input
                      type="text"
                      name="contactName"
                      required
                      value={formData.contactName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Server Type
                    </label>
                    <select
                      name="serverType"
                      required
                      value={formData.serverType}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    >
                      <option value="physical">Physical Server</option>
                      <option value="virtual">Virtual Machine</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Environment
                    </label>
                    <input
                      type="text"
                      name="environment"
                      placeholder="e.g., Production, Staging"
                      required
                      value={formData.environment}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Expected Daily Transactions
                  </label>
                  <input
                    type="text"
                    name="expectedTransactions"
                    placeholder="e.g., 100,000"
                    required
                    value={formData.expectedTransactions}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition duration-300"
                >
                  Continue to Docker Setup
                </button>
              </form>
            </div>
          ) : showDockerGuide ? (
            <div id="docker-guide" className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-lg">
              <h3 className="text-2xl font-semibold mb-6">Docker Setup Guide</h3>
              
              <div className="space-y-8">
                <div className="bg-gray-50 p-6 rounded-lg">
                  <h4 className="text-xl font-semibold mb-4 flex items-center">
                    <Terminal className="h-6 w-6 mr-2 text-indigo-600" />
                    Step 1: Pull FraudX Docker Image
                  </h4>
                  <pre className="bg-gray-900 text-white p-4 rounded-lg overflow-x-auto">
                    <code>docker pull fraudx/enterprise:latest</code>
                  </pre>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h4 className="text-xl font-semibold mb-4 flex items-center">
                    <Settings className="h-6 w-6 mr-2 text-indigo-600" />
                    Step 2: Configure Environment
                  </h4>
                  <pre className="bg-gray-900 text-white p-4 rounded-lg overflow-x-auto">
                    <code>{`# Create configuration directory
mkdir -p /opt/fraudx/config

# Copy configuration template
cp fraudx.yml.template /opt/fraudx/config/fraudx.yml

# Set proper permissions
chmod 600 /opt/fraudx/config/fraudx.yml`}</code>
                  </pre>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h4 className="text-xl font-semibold mb-4 flex items-center">
                    <HardDrive className="h-6 w-6 mr-2 text-indigo-600" />
                    Step 3: Start FraudX Container
                  </h4>
                  <pre className="bg-gray-900 text-white p-4 rounded-lg overflow-x-auto">
                    <code>{`docker run -d \\
  --name fraudx \\
  -v /opt/fraudx/config:/etc/fraudx \\
  -p 8080:8080 \\
  -p 9090:9090 \\
  --restart unless-stopped \\
  fraudx/enterprise:latest`}</code>
                  </pre>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h4 className="text-xl font-semibold mb-4 flex items-center">
                    <CheckCircle2 className="h-6 w-6 mr-2 text-indigo-600" />
                    Step 4: Verify Installation
                  </h4>
                  <pre className="bg-gray-900 text-white p-4 rounded-lg overflow-x-auto">
                    <code>{`# Check container status
docker ps | grep fraudx

# View logs
docker logs fraudx

# Test API endpoint
curl http://localhost:8080/health`}</code>
                  </pre>
                </div>
              </div>

              <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                <p className="text-blue-800">
                  <strong>Note:</strong> Make sure to replace the configuration values in fraudx.yml with your specific settings before starting the container.
                </p>
              </div>
            </div>
          ) : (
            <div className="max-w-4xl mx-auto">
              <div className="space-y-12">
                <OnboardingStep
                  number="1"
                  title="Technical Assessment & Planning"
                  description="Complete infrastructure evaluation and deployment planning."
                  details={[
                    "Infrastructure requirements assessment",
                    "Security compliance verification",
                    "Network architecture planning",
                    "Data flow mapping"
                  ]}
                />
                <OnboardingStep
                  number="2"
                  title="Security Configuration"
                  description="Set up secure access controls and encryption protocols."
                  details={[
                    "SSL/TLS certificate configuration",
                    "Network security rules setup",
                    "Access control implementation",
                    "Audit logging configuration"
                  ]}
                />
                <OnboardingStep
                  number="3"
                  title="Docker Environment Setup"
                  description="Secure containerized deployment preparation."
                  details={[
                    "Docker environment validation",
                    "Container security hardening",
                    "Network isolation setup",
                    "Resource allocation configuration"
                  ]}
                />
                <OnboardingStep
                  number="4"
                  title="Integration & Testing"
                  description="System integration and security testing."
                  details={[
                    "API integration testing",
                    "Performance validation",
                    "Security penetration testing",
                    "Failover verification"
                  ]}
                />
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-16">
            Enterprise Security Features
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard
              icon={<Server className="h-8 w-8 text-indigo-600" />}
              title="Local Deployment"
              description="Complete control over your infrastructure with on-premises deployment."
            />
            <FeatureCard
              icon={<Database className="h-8 w-8 text-indigo-600" />}
              title="Data Sovereignty"
              description="All data remains within your secure infrastructure."
            />
            <FeatureCard
              icon={<Lock className="h-8 w-8 text-indigo-600" />}
              title="Bank-Grade Security"
              description="Military-grade encryption and security protocols."
            />
            <FeatureCard
              icon={<FileText className="h-8 w-8 text-indigo-600" />}
              title="Audit Compliance"
              description="Detailed audit logs and compliance reporting."
            />
          </div>
        </div>
      </section>

      {/* Technical Requirements Section */}
      <section id="security" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-800 mb-16">
              Technical Prerequisites
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gray-50 p-8 rounded-lg">
                <h3 className="text-xl font-semibold mb-4">Hardware Requirements</h3>
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                    <span>16+ CPU Cores</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                    <span>32GB+ RAM</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                    <span>500GB+ SSD Storage</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                    <span>Redundant Power Supply</span>
                  </li>
                </ul>
              </div>
              <div className="bg-gray-50 p-8 rounded-lg">
                <h3 className="text-xl font-semibold mb-4">Software Requirements</h3>
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                    <span>Docker Engine 20.10+</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                    <span>Linux Kernel 5.4+</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                    <span>SSL Certificates</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                    <span>Network Firewall</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-indigo-600 py-20">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-8">
            Ready to Implement FraudX?
          </h2>
          <p className="text-indigo-100 mb-8 max-w-2xl mx-auto">
            Our implementation team will guide you through every step of the secure deployment process.
          </p>
          <button 
            onClick={handleStartImplementation}
            className="bg-white text-indigo-600 px-8 py-3 rounded-lg hover:bg-indigo-50 transition duration-300 font-semibold"
          >
            Start Implementation Now
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-8 md:mb-0">
              <div className="flex items-center cursor-pointer" onClick={() => scrollToSection('top')}>
                <Shield className="h-8 w-8 text-indigo-400" />
                <span className="ml-2 text-xl font-bold">FraudX</span>
              </div>
              <p className="mt-4 text-gray-400 max-w-sm">
                Enterprise-grade fraud detection with complete data sovereignty.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-12">
              <div>
                <h3 className="text-lg font-semibold mb-4">Implementation</h3>
                <ul className="space-y-2">
                  <li><button onClick={() => scrollToSection('onboarding')} className="text-gray-400 hover:text-white transition duration-300">Guide</button></li>
                  <li><button onClick={() => scrollToSection('security')} className="text-gray-400 hover:text-white transition duration-300">Requirements</button></li>
                  <li><button onClick={() => scrollToSection('features')} className="text-gray-400 hover:text-white transition duration-300">Security</button></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Company</h3>
                <ul className="space-y-2">
                  <li><button className="text-gray-400 hover:text-white transition duration-300">About</button></li>
                  <li><button className="text-gray-400 hover:text-white transition duration-300">Contact</button></li>
                  <li><button className="text-gray-400 hover:text-white transition duration-300">Support</button></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Resources</h3>
                <ul className="space-y-2">
                  <li><button onClick={() => scrollToSection('onboarding')} className="text-gray-400 hover:text-white transition duration-300">Documentation</button></li>
                  <li><button className="text-gray-400 hover:text-white transition duration-300">API Reference</button></li>
                  <li><button className="text-gray-400 hover:text-white transition duration-300">Status</button></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2025 FraudX. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition duration-300">
      <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center mb-6">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function OnboardingStep({ number, title, description, details }: OnboardingStepProps) {
  return (
    <div className="flex items-start">
      <div className="flex-shrink-0 w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center font-semibold">
        {number}
      </div>
      <div className="ml-4 flex-1">
        <h3 className="text-xl font-semibold text-gray-800">{title}</h3>
        <p className="mt-2 text-gray-600">{description}</p>
        {details && (
          <ul className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-2">
            {details.map((detail, index) => (
              <li key={index} className="flex items-center text-sm text-gray-600">
                <ChevronRight className="h-4 w-4 text-indigo-600 mr-2" />
                {detail}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default App;